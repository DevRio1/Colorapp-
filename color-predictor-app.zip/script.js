function predictColor() {
  const colors = ["Red", "Black"];
  const randomIndex = Math.floor(Math.random() * colors.length);
  const result = colors[randomIndex];

  document.getElementById("result").textContent = `Predicted Color: ${result}`;
}